public class GameLoop {
    //Sets up the gameBoard
    private Board gameboard = new Board();

    /**
     * runGame: Runs the game class
     */
    public void runGame(){

    }
}
