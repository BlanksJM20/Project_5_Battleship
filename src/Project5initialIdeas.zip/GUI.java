public class GUI {
    //We are going to do more research on GUI but don't know exactly what methods to put, but here is the
    //stub class
}
