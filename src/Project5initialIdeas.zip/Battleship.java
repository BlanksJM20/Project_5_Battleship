public class Battleship {
    /**
     * runs battleship
     * @param args
     */
    public static void main(String[] args) {
        //System.out.println("Hello world!");
    }
}